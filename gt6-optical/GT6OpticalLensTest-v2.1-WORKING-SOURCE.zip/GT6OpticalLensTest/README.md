# GT6 Optical Lens Test v2.1

Рабочий Android Studio проект-диагност для проверки камер realme GT6.

## Что исправлено относительно v2.0

- TELE-кандидат выбирается только внутри physical-набора выбранной logical rear camera.
- Есть fallback по focal length, если OEM скрывает physical sensor size.
- FORCE PHYS проверяет, что physical ID действительно принадлежит logical camera.
- Preview для теста запрашивается около 1920×1080 для лучшей совместимости logical/physical комбинаций.
- Ошибки FORCE PHYS и zoom больше не должны валить Activity: они выводятся в HUD/Toast.
- Старые ZoomState observers удаляются при каждом rebinding.
- В HUD добавлен `CONFIRM` для FORCE PHYS.
- Добавлена кнопка `RESCAN`.
- Версия 2.1, versionCode 3.

## Как тестировать

1. MAIN 1× — скрин HUD.
2. LOGICAL 2× — подождать 1–2 секунды; смотреть ACTIVE PHYS и FRAME f.
3. Плавно 1×→3× — смотреть момент смены ACTIVE PHYS.
4. FORCE PHYS — `CONFIRM=YES` является прямым подтверждением, если OEM публикует active physical ID.
5. TELE DIRECT — доступна только если tele опубликована как public cameraId.
6. COPY INFO — прислать полный текст диагностики.

`RESULT KEY=NO` означает, что OEM не публикует `LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID`; это не доказывает отсутствие реального переключения.

## Сборка

- JDK 17
- Android SDK 35
- Gradle 8.9
- AGP 8.7.3
- Kotlin 2.0.21
- CameraX 1.4.2

Открыть `GT6OpticalLensTest` в Android Studio, дождаться Gradle Sync и выполнить `Build > Build APK(s)`.
Либо запустить `build_debug.sh`/`build_debug.bat`, если Gradle 8.9 установлен глобально.

GitHub Actions workflow `.github/workflows/build-apk.yml` также собирает debug APK и загружает его как artifact.
