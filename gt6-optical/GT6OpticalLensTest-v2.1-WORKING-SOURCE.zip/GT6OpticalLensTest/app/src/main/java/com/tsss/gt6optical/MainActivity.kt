package com.tsss.gt6optical

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Build
import android.os.Bundle
import android.util.Range
import android.util.Size
import android.util.SizeF
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.tsss.gt6optical.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraManager: CameraManager
    private lateinit var cameraExecutor: ExecutorService

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private var records: List<CameraRecord> = emptyList()
    private var recordById: Map<String, CameraRecord> = emptyMap()

    private var activeCameraId: String? = null
    private var forcedPhysicalId: String? = null
    private var activePhysicalIdFromResult: String? = null
    private var captureFocalMm: Float? = null
    private var captureZoomRatio: Float? = null
    private var captureFps = 0f
    private var lastSensorTimestampNs = 0L
    private var lastHudUpdateNs = 0L

    private var mainRearId: String? = null
    private var logicalRearId: String? = null
    private var teleDirectId: String? = null
    private var telePhysicalCandidateId: String? = null
    private var diagnostics: String = ""

    private data class CameraRecord(
        val id: String,
        val listed: Boolean,
        val parentLogicalId: String?,
        val facing: Int?,
        val focalLengths: FloatArray,
        val sensorSize: SizeF?,
        val physicalIds: Set<String>,
        val capabilities: IntArray,
        val zoomRatioRange: Range<Float>?,
        val hardwareLevel: Int?,
        val activePhysicalResultKey: Boolean
    ) {
        val maxFocal: Float get() = focalLengths.maxOrNull() ?: 0f
        val sensorWidth: Float get() = sensorSize?.width ?: 0f
        val sensorArea: Float get() = (sensorSize?.width ?: 0f) * (sensorSize?.height ?: 0f)
        val eq35Horizontal: Float
            get() = if (maxFocal > 0f && sensorWidth > 0f) maxFocal * 36f / sensorWidth else 0f
        val isLogical: Boolean
            get() = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCameraSystem() else binding.status.text = "CAMERA permission denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnMain.setOnClickListener {
            mainRearId?.let { bindCamera(it, 1f, null) } ?: toast("Main camera не найдена")
        }
        binding.btnLogical2x.setOnClickListener {
            val id = logicalRearId ?: mainRearId
            if (id == null) toast("Logical/main camera не найдена") else bindCamera(id, 2f, null)
        }
        binding.btnTele.setOnClickListener {
            val id = teleDirectId
            if (id == null) toast("Публичный TELE cameraId не найден") else bindCamera(id, 1f, null)
        }
        binding.btnForcePhysical.setOnClickListener {
            val logical = logicalRearId
            val physical = telePhysicalCandidateId
            when {
                logical == null -> toast("Logical rear camera не найдена")
                physical == null -> toast("Physical TELE candidate не найден")
                else -> bindCamera(logical, 1f, physical)
            }
        }
        binding.btnRescan.setOnClickListener {
            scanAllCameras()
            toast("Камеры пересканированы")
        }
        binding.btnDump.setOnClickListener { copyDiagnostics() }

        binding.zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val zs = camera?.cameraInfo?.zoomState?.value ?: return
                val min = zs.minZoomRatio
                val max = zs.maxZoomRatio
                val ratio = min + (max - min) * (progress / 1000f)
                requestZoom(ratio, reportError = false)
                binding.zoomLabel.text = "Zoom %.2f×".format(Locale.US, ratio)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraSystem()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCameraSystem() {
        scanAllCameras()
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            mainRearId?.let { bindCamera(it, 1f, null) } ?: toast("Задняя камера не найдена")
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanAllCameras() {
        val listedIds = cameraManager.cameraIdList.toSet()
        val listedRecords = listedIds.mapNotNull { readRecord(it, listed = true, parentLogicalId = null) }
        val rearListed = listedRecords.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }

        val logical = rearListed
            .filter { it.isLogical && it.physicalIds.isNotEmpty() }
            .maxWithOrNull(compareBy<CameraRecord> { it.physicalIds.size }.thenBy { it.sensorArea })

        logicalRearId = logical?.id
        mainRearId = logical?.id ?: rearListed.maxByOrNull { it.sensorArea }?.id

        val physicalRecords = rearListed
            .filter { it.isLogical && it.physicalIds.isNotEmpty() }
            .flatMap { parent ->
                parent.physicalIds.mapNotNull { pid ->
                    readRecord(pid, listed = listedIds.contains(pid), parentLogicalId = parent.id)
                }
            }
            .distinctBy { it.id }

        records = (listedRecords + physicalRecords).distinctBy { "${it.id}|${it.parentLogicalId ?: "-"}" }
        recordById = records.groupBy { it.id }.mapValues { it.value.first() }

        // Pick TELE only from the physical set of the selected logical rear camera.
        // v2.0 could accidentally pick a sensor belonging to another logical rear camera.
        val selectedLogicalPhysical = physicalRecords
            .filter { it.parentLogicalId == logicalRearId }
            .distinctBy { it.id }

        telePhysicalCandidateId = selectTeleCandidate(selectedLogicalPhysical)

        // TELE DIRECT is only claimed if that tele candidate is actually public/listed.
        teleDirectId = telePhysicalCandidateId?.takeIf { listedIds.contains(it) }

        // Fallback for phones exposing separate public rear IDs without logical physical metadata.
        if (telePhysicalCandidateId == null) {
            val optical = rearListed.filter { it.id != mainRearId && it.eq35Horizontal > 0f }
            val baseline = rearListed.filter { it.eq35Horizontal > 0f }
                .minOfOrNull { it.eq35Horizontal } ?: 0f
            val best = optical.maxByOrNull { it.eq35Horizontal }
            if (best != null && baseline > 0f && best.eq35Horizontal >= baseline * 1.35f) {
                teleDirectId = best.id
            } else {
                val byFocal = rearListed.filter { it.id != mainRearId && it.maxFocal > 0f }
                val focalBase = rearListed.filter { it.maxFocal > 0f }.minOfOrNull { it.maxFocal } ?: 0f
                val focalBest = byFocal.maxByOrNull { it.maxFocal }
                if (focalBest != null && focalBase > 0f && focalBest.maxFocal >= focalBase * 1.35f) {
                    teleDirectId = focalBest.id
                }
            }
        }

        diagnostics = buildDiagnostics(listedIds)
        binding.status.text = compactSummary()
        updateLiveStatus()
    }

    private fun selectTeleCandidate(candidates: List<CameraRecord>): String? {
        if (candidates.size < 2) return null

        // Preferred: normalize focal length by sensor width (approx. horizontal 35 mm equivalent).
        val withEq = candidates.filter { it.eq35Horizontal > 0f }
        if (withEq.size >= 2) {
            val minEq = withEq.minOf { it.eq35Horizontal }
            val best = withEq.maxByOrNull { it.eq35Horizontal } ?: return null
            if (minEq > 0f && best.eq35Horizontal >= minEq * 1.30f) return best.id
        }

        // OEM fallback: hidden physical cameras sometimes omit SENSOR_INFO_PHYSICAL_SIZE.
        val withFocal = candidates.filter { it.maxFocal > 0f }
        if (withFocal.size >= 2) {
            val minFocal = withFocal.minOf { it.maxFocal }
            val best = withFocal.maxByOrNull { it.maxFocal } ?: return null
            if (minFocal > 0f && best.maxFocal >= minFocal * 1.35f) return best.id
        }
        return null
    }

    private fun readRecord(id: String, listed: Boolean, parentLogicalId: String?): CameraRecord? = runCatching {
        val c = cameraManager.getCameraCharacteristics(id)
        val resultKeys = runCatching { c.availableCaptureResultKeys }.getOrNull()
        CameraRecord(
            id = id,
            listed = listed,
            parentLogicalId = parentLogicalId,
            facing = c.get(CameraCharacteristics.LENS_FACING),
            focalLengths = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS) ?: floatArrayOf(),
            sensorSize = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE),
            physicalIds = c.physicalCameraIds,
            capabilities = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf(),
            zoomRatioRange = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null,
            hardwareLevel = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL),
            activePhysicalResultKey = resultKeys?.contains(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID) == true
        )
    }.getOrNull()

    private fun buildDiagnostics(listedIds: Set<String>): String = buildString {
        appendLine("GT6 Optical Lens Test v2.1")
        appendLine("Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
        appendLine("Device ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("listedCameraIds=${listedIds.sorted()}")
        appendLine("mainRearId=$mainRearId")
        appendLine("logicalRearId=$logicalRearId")
        appendLine("teleDirectId=$teleDirectId")
        appendLine("telePhysicalCandidateId=$telePhysicalCandidateId")
        appendLine()
        records.forEach { r ->
            appendLine("cameraId=${r.id}${if (r.listed) " [PUBLIC]" else " [PHYSICAL/HIDDEN]"}")
            appendLine("  parentLogicalId=${r.parentLogicalId ?: "-"}")
            appendLine("  facing=${facingName(r.facing)}")
            appendLine("  logical=${r.isLogical}")
            appendLine("  focalLengths=${r.focalLengths.joinToString(prefix = "[", postfix = "]") { "%.2f".format(Locale.US, it) }} mm")
            appendLine("  sensorSize=${r.sensorSize?.width}x${r.sensorSize?.height} mm")
            appendLine("  eq35Horizontal≈${if (r.eq35Horizontal > 0f) "%.1f".format(Locale.US, r.eq35Horizontal) else "?"} mm")
            appendLine("  physicalIds=${if (r.physicalIds.isEmpty()) "[]" else r.physicalIds}")
            appendLine("  activePhysicalResultKey=${r.activePhysicalResultKey}")
            appendLine("  zoomRatioRange=${r.zoomRatioRange ?: "n/a"}")
            appendLine("  HW=${hardwareLevelName(r.hardwareLevel)}")
            appendLine("  caps=${r.capabilities.joinToString()}")
        }
    }

    private fun compactSummary(): String {
        val publicRear = records.filter { it.listed && it.facing == CameraCharacteristics.LENS_FACING_BACK }
        val physical = records.filter { it.parentLogicalId != null }
        return buildString {
            appendLine("PUBLIC rear: ${publicRear.size}   PHYSICAL: ${physical.distinctBy { it.id }.size}")
            appendLine("MAIN=$mainRearId   LOGICAL=${logicalRearId ?: "-"}")
            appendLine("TELE direct=${teleDirectId ?: "-"}")
            appendLine("TELE physical=${telePhysicalCandidateId ?: "-"}")
            publicRear.forEach { r ->
                append("ID ${r.id}: f=${focalText(r)}")
                if (r.eq35Horizontal > 0f) append("  eq≈${"%.0f".format(Locale.US, r.eq35Horizontal)}mm")
                if (r.isLogical) append("  LOGICAL p=${r.physicalIds}")
                appendLine()
            }
            physical.distinctBy { it.id }.forEach { r ->
                append("P ${r.id}: f=${focalText(r)}")
                if (r.eq35Horizontal > 0f) append("  eq≈${"%.0f".format(Locale.US, r.eq35Horizontal)}mm")
                appendLine("  parent=${r.parentLogicalId}")
            }
        }
    }

    private fun bindCamera(cameraId: String, initialZoom: Float, physicalId: String?) {
        val provider = provider ?: return

        if (physicalId != null) {
            val valid = recordById[cameraId]?.physicalIds ?: emptySet()
            if (physicalId !in valid) {
                toast("Physical $physicalId не принадлежит logical $cameraId")
                return
            }
        }

        runCatching {
            val selector = CameraSelector.Builder()
                .addCameraFilter { infos ->
                    infos.filter { info ->
                        runCatching { Camera2CameraInfo.from(info).cameraId == cameraId }
                            .getOrDefault(false)
                    }
                }
                .build()

            // Conservative 1080p preview improves compatibility with logical/physical camera combinations.
            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1920, 1080),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val previewBuilder = Preview.Builder().setResolutionSelector(resolutionSelector)
            Camera2Interop.Extender(previewBuilder).apply {
                setSessionCaptureCallback(captureCallback)
                if (physicalId != null) setPhysicalCameraId(physicalId)
            }
            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.preview.surfaceProvider)
            }

            // Remove observers from the previous CameraInfo before rebinding.
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            provider.unbindAll()
            resetCaptureTelemetry()

            camera = provider.bindToLifecycle(this, selector, preview)
            activeCameraId = cameraId
            forcedPhysicalId = physicalId
            observeZoom(cameraId, initialZoom)
            updateLiveStatus()
        }.onFailure { e ->
            forcedPhysicalId = null
            activeCameraId = null
            camera = null
            toast("Не удалось открыть $cameraId${physicalId?.let { " / phys=$it" } ?: ""}: ${e.javaClass.simpleName}")
            binding.liveStatus.text = "OPEN ERROR: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            activePhysicalIdFromResult = runCatching {
                result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID)
            }.getOrNull()
            captureFocalMm = runCatching { result.get(CaptureResult.LENS_FOCAL_LENGTH) }.getOrNull()
            captureZoomRatio = if (Build.VERSION.SDK_INT >= 30) {
                runCatching { result.get(CaptureResult.CONTROL_ZOOM_RATIO) }.getOrNull()
            } else null

            val sensorTs = runCatching { result.get(CaptureResult.SENSOR_TIMESTAMP) }.getOrNull() ?: 0L
            if (sensorTs > 0L && lastSensorTimestampNs > 0L) {
                val dt = sensorTs - lastSensorTimestampNs
                if (dt in 1_000_000L..1_000_000_000L) {
                    val instant = 1_000_000_000f / dt.toFloat()
                    captureFps = if (captureFps <= 0f) instant else captureFps * 0.90f + instant * 0.10f
                }
            }
            if (sensorTs > 0L) lastSensorTimestampNs = sensorTs

            val now = System.nanoTime()
            if (now - lastHudUpdateNs >= 180_000_000L) {
                lastHudUpdateNs = now
                runOnUiThread { updateLiveStatus() }
            }
        }
    }

    private fun observeZoom(cameraId: String, initialZoom: Float) {
        val cam = camera ?: return
        cam.cameraInfo.zoomState.observe(this) { zs ->
            if (zs == null) return@observe
            val min = zs.minZoomRatio
            val max = max(min, zs.maxZoomRatio)
            val now = zs.zoomRatio
            binding.zoomLabel.text = "Zoom %.2f×  [%.1f..%.1f]".format(Locale.US, now, min, max)
            val p = if (max <= min) 0 else (((now - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
            binding.zoomSeek.progress = p
        }

        val range = recordById[cameraId]?.zoomRatioRange
        val desired = if (range != null) initialZoom.coerceIn(range.lower, range.upper) else initialZoom.coerceAtLeast(1f)
        requestZoom(desired, reportError = true)
    }

    private fun requestZoom(ratio: Float, reportError: Boolean) {
        val cam = camera ?: return
        val future = runCatching { cam.cameraControl.setZoomRatio(ratio) }.getOrElse { e ->
            if (reportError) toast("Zoom error: ${e.javaClass.simpleName}")
            return
        }
        future.addListener({
            runCatching { future.get() }.onFailure { e ->
                if (reportError) runOnUiThread {
                    toast("Zoom %.2f× rejected: %s".format(Locale.US, ratio, e.javaClass.simpleName))
                }
            }
        }, cameraExecutor)
    }

    private fun updateLiveStatus() {
        val openId = activeCameraId ?: "-"
        val openRecord = recordById[openId]
        val metadataPhysical = activePhysicalIdFromResult
        val effective = when {
            metadataPhysical != null -> metadataPhysical
            forcedPhysicalId != null -> "${forcedPhysicalId} (requested)"
            openRecord?.isLogical == false -> openId
            else -> "UNKNOWN"
        }
        val teleMatch = telePhysicalCandidateId != null && metadataPhysical == telePhysicalCandidateId
        val forceConfirm = when {
            forcedPhysicalId == null -> "n/a"
            metadataPhysical == forcedPhysicalId -> "YES"
            metadataPhysical != null -> "NO"
            else -> "?"
        }
        val keyState = when {
            openRecord == null -> "?"
            openRecord.activePhysicalResultKey -> "YES"
            else -> "NO"
        }

        binding.liveStatus.text = buildString {
            appendLine("OPEN $openId${if (openRecord?.isLogical == true) "  LOGICAL" else ""}")
            appendLine("FORCED PHYS=${forcedPhysicalId ?: "-"}   CONFIRM=$forceConfirm")
            appendLine("ACTIVE PHYS=$effective")
            append("TELE MATCH=").append(if (teleMatch) "YES" else if (metadataPhysical == null) "?" else "NO")
            append("   RESULT KEY=$keyState")
            appendLine()
            append("FRAME f=").append(captureFocalMm?.let { "%.2fmm".format(Locale.US, it) } ?: "?")
            append("   zoom=").append(captureZoomRatio?.let { "%.2f×".format(Locale.US, it) } ?: "?")
            append("   CAP=").append(if (captureFps > 0f) "%.1f fps".format(Locale.US, captureFps) else "?")
        }
    }

    private fun resetCaptureTelemetry() {
        activePhysicalIdFromResult = null
        captureFocalMm = null
        captureZoomRatio = null
        captureFps = 0f
        lastSensorTimestampNs = 0L
        lastHudUpdateNs = 0L
    }

    private fun focalText(r: CameraRecord): String =
        if (r.focalLengths.isEmpty()) "?" else r.focalLengths.joinToString("/") { "%.1fmm".format(Locale.US, it) }

    private fun copyDiagnostics() {
        val live = buildString {
            appendLine(diagnostics)
            appendLine("--- LIVE ---")
            appendLine("activeCameraId=$activeCameraId")
            appendLine("forcedPhysicalId=$forcedPhysicalId")
            appendLine("activePhysicalIdFromResult=$activePhysicalIdFromResult")
            appendLine("captureFocalMm=$captureFocalMm")
            appendLine("captureZoomRatio=$captureZoomRatio")
            appendLine("captureFps=${"%.2f".format(Locale.US, captureFps)}")
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("GT6 camera diagnostics v2", live))
        toast("Camera diagnostics v2 скопированы")
    }

    private fun facingName(v: Int?): String = when (v) {
        CameraCharacteristics.LENS_FACING_BACK -> "BACK"
        CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
        CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
        else -> "UNKNOWN"
    }

    private fun hardwareLevelName(v: Int?): String = when (v) {
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
        else -> "UNKNOWN"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        camera?.cameraInfo?.zoomState?.removeObservers(this)
        provider?.unbindAll()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
