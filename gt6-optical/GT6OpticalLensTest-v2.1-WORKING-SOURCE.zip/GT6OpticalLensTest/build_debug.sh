#!/usr/bin/env sh
set -eu
gradle --no-daemon --stacktrace :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
