package com.tsss.gt6optical

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.os.Build
import android.os.Bundle
import android.util.Range
import android.util.Size
import android.util.SizeF
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.tsss.gt6optical.databinding.ActivityMainBinding
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraManager: CameraManager
    private lateinit var cameraExecutor: ExecutorService

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null

    private var records: List<CameraRecord> = emptyList()
    private var recordById: Map<String, CameraRecord> = emptyMap()

    private var activeCameraId: String? = null
    private var forcedPhysicalId: String? = null
    private var activePhysicalIdFromResult: String? = null
    private var captureFocalMm: Float? = null
    private var captureZoomRatio: Float? = null
    private var captureFps = 0f
    private var lastSensorTimestampNs = 0L
    private var lastHudUpdateNs = 0L

    private var mainRearId: String? = null
    private var logicalRearId: String? = null
    private var teleDirectId: String? = null
    private var telePhysicalCandidateId: String? = null
    private var mainPhysicalCandidateId: String? = null
    private var requestedFpsRange: Range<Int>? = null
    private var diagnostics: String = ""

    private data class CameraRecord(
        val id: String,
        val listed: Boolean,
        val parentLogicalId: String?,
        val facing: Int?,
        val focalLengths: FloatArray,
        val sensorSize: SizeF?,
        val physicalIds: Set<String>,
        val capabilities: IntArray,
        val zoomRatioRange: Range<Float>?,
        val aeFpsRanges: List<Range<Int>>,
        val highSpeedProfiles: List<String>,
        val hardwareLevel: Int?,
        val activePhysicalResultKey: Boolean
    ) {
        val maxFocal: Float get() = focalLengths.maxOrNull() ?: 0f
        val sensorWidth: Float get() = sensorSize?.width ?: 0f
        val sensorArea: Float get() = (sensorSize?.width ?: 0f) * (sensorSize?.height ?: 0f)
        val eq35Horizontal: Float
            get() = if (maxFocal > 0f && sensorWidth > 0f) maxFocal * 36f / sensorWidth else 0f
        val isLogical: Boolean
            get() = capabilities.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA)
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCameraSystem() else binding.status.text = "CAMERA permission denied"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraExecutor = Executors.newSingleThreadExecutor()

        binding.btnMain.setOnClickListener {
            mainRearId?.let { bindCamera(it, 1f, null) } ?: toast("Main camera не найдена")
        }
        binding.btnLogical2x.setOnClickListener {
            val id = logicalRearId ?: mainRearId
            if (id == null) toast("Logical/main camera не найдена") else bindCamera(id, 2f, null)
        }
        binding.btnTele.setOnClickListener {
            val id = teleDirectId
            if (id == null) toast("Публичный TELE cameraId не найден") else bindCamera(id, 1f, null)
        }
        binding.btnForcePhysical.setOnClickListener {
            val logical = logicalRearId
            val physical = telePhysicalCandidateId
            when {
                logical == null -> toast("Logical rear camera не найдена")
                physical == null -> toast("Physical TELE candidate не найден")
                else -> bindCamera(logical, 1f, physical)
            }
        }
        binding.btnRescan.setOnClickListener {
            scanAllCameras()
            toast("Камеры пересканированы")
        }
        binding.btnFpsAuto.setOnClickListener {
            requestedFpsRange = null
            rebindCurrentCamera()
        }
        binding.btnFps60.setOnClickListener {
            val id = activeCameraId ?: logicalRearId ?: mainRearId
            val rec = id?.let { recordById[it] }
            val range = rec?.let { selectFpsRange(it, 60) }
            if (range == null) {
                toast("60 FPS range не заявлен этой камерой")
            } else {
                requestedFpsRange = range
                rebindCurrentCamera()
            }
        }
        binding.btnDump.setOnClickListener { copyDiagnostics() }

        binding.zoomSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val zs = camera?.cameraInfo?.zoomState?.value ?: return
                val min = zs.minZoomRatio
                val max = zs.maxZoomRatio
                val ratio = min + (max - min) * (progress / 1000f)
                requestZoom(ratio, reportError = false)
                binding.zoomLabel.text = "Zoom %.2f×".format(Locale.US, ratio)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCameraSystem()
        } else {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCameraSystem() {
        scanAllCameras()
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            mainRearId?.let { bindCamera(it, 1f, null) } ?: toast("Задняя камера не найдена")
        }, ContextCompat.getMainExecutor(this))
    }

    private fun scanAllCameras() {
        val listedIds = cameraManager.cameraIdList.toSet()
        val listedRecords = listedIds.mapNotNull { readRecord(it, listed = true, parentLogicalId = null) }
        val rearListed = listedRecords.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }

        val logical = rearListed
            .filter { it.isLogical && it.physicalIds.isNotEmpty() }
            .maxWithOrNull(compareBy<CameraRecord> { it.physicalIds.size }.thenBy { it.sensorArea })

        logicalRearId = logical?.id
        mainRearId = logical?.id ?: rearListed.maxByOrNull { it.sensorArea }?.id

        val physicalRecords = rearListed
            .filter { it.isLogical && it.physicalIds.isNotEmpty() }
            .flatMap { parent ->
                parent.physicalIds.mapNotNull { pid ->
                    readRecord(pid, listed = listedIds.contains(pid), parentLogicalId = parent.id)
                }
            }
            .distinctBy { it.id }

        records = (listedRecords + physicalRecords).distinctBy { "${it.id}|${it.parentLogicalId ?: "-"}" }
        recordById = records.groupBy { it.id }.mapValues { it.value.first() }

        // Classify physical cameras RELATIVE TO THE selected logical/main camera.
        // v2.1 used the smallest optical module as a baseline, so MAIN could be mislabeled TELE.
        val selectedLogicalPhysical = physicalRecords
            .filter { it.parentLogicalId == logicalRearId }
            .distinctBy { it.id }

        mainPhysicalCandidateId = selectedLogicalPhysical
            .filter { cameraRole(it) == "MAIN" }
            .minByOrNull { opticalDistanceFromMain(it) }
            ?.id

        telePhysicalCandidateId = selectedLogicalPhysical
            .filter { cameraRole(it) == "TELE" }
            .maxByOrNull { opticalStrength(it) }
            ?.id

        // TELE DIRECT is only valid when a genuine TELE-role camera is public/listed.
        teleDirectId = telePhysicalCandidateId?.takeIf { listedIds.contains(it) }

        // Fallback for phones exposing separate public rear IDs without logical physical metadata.
        if (teleDirectId == null) {
            teleDirectId = rearListed
                .filter { it.id != mainRearId && cameraRole(it) == "TELE" }
                .maxByOrNull { opticalStrength(it) }
                ?.id
        }

        diagnostics = buildDiagnostics(listedIds)
        binding.status.text = compactSummary()
        updateLiveStatus()
    }

    private fun mainOpticalBaseline(): CameraRecord? {
        return logicalRearId?.let { recordById[it] }
            ?: mainRearId?.let { recordById[it] }
    }

    private fun opticalStrength(r: CameraRecord): Float =
        when {
            r.eq35Horizontal > 0f -> r.eq35Horizontal
            r.maxFocal > 0f -> r.maxFocal
            else -> 0f
        }

    private fun opticalDistanceFromMain(r: CameraRecord): Float {
        val base = mainOpticalBaseline() ?: return Float.MAX_VALUE
        return when {
            r.eq35Horizontal > 0f && base.eq35Horizontal > 0f ->
                kotlin.math.abs(r.eq35Horizontal / base.eq35Horizontal - 1f)
            r.maxFocal > 0f && base.maxFocal > 0f ->
                kotlin.math.abs(r.maxFocal / base.maxFocal - 1f)
            else -> Float.MAX_VALUE
        }
    }

    /**
     * Role is relative to the MAIN logical camera, not relative to the shortest lens.
     * GT6 test result:
     *   logical 0 ≈24 mm eq
     *   physical 2 ≈24 mm eq -> MAIN
     *   physical 3 ≈17 mm eq -> ULTRA
     */
    private fun cameraRole(r: CameraRecord): String {
        val base = mainOpticalBaseline() ?: return "UNKNOWN"

        if (r.eq35Horizontal > 0f && base.eq35Horizontal > 0f) {
            val ratio = r.eq35Horizontal / base.eq35Horizontal
            return when {
                ratio < 0.85f -> "ULTRA"
                ratio > 1.25f -> "TELE"
                else -> "MAIN"
            }
        }

        // Fallback when the OEM hides physical sensor dimensions.
        if (r.maxFocal > 0f && base.maxFocal > 0f) {
            val ratio = r.maxFocal / base.maxFocal
            return when {
                ratio < 0.80f -> "ULTRA"
                ratio > 1.35f -> "TELE"
                else -> "MAIN"
            }
        }
        return "UNKNOWN"
    }

    private fun selectFpsRange(r: CameraRecord, target: Int): Range<Int>? {
        val candidates = r.aeFpsRanges.filter { it.lower <= target && it.upper >= target }
        return candidates.minWithOrNull(
            compareBy<Range<Int>>(
                { kotlin.math.abs(it.upper - it.lower) },
                { kotlin.math.abs(it.lower - target) },
                { kotlin.math.abs(it.upper - target) }
            )
        )
    }

    private fun rebindCurrentCamera() {
        val id = activeCameraId ?: logicalRearId ?: mainRearId ?: run {
            toast("Камера не выбрана")
            return
        }
        val zoom = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f
        bindCamera(id, zoom, forcedPhysicalId)
    }

    private fun readRecord(
        id: String,
        listed: Boolean,
        parentLogicalId: String?
    ): CameraRecord? = runCatching {
        val c = cameraManager.getCameraCharacteristics(id)
        val resultKeys = runCatching { c.availableCaptureResultKeys }.getOrNull()
        val streamMap = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val aeRanges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            ?.toList() ?: emptyList()
        val hsProfiles = if (Build.VERSION.SDK_INT >= 23 && streamMap != null) {
            runCatching {
                streamMap.highSpeedVideoSizes.flatMap { size ->
                    streamMap.getHighSpeedVideoFpsRangesFor(size).map { range ->
                        "${size.width}x${size.height}@${range.lower}-${range.upper}"
                    }
                }.distinct().sorted()
            }.getOrDefault(emptyList())
        } else {
            emptyList()
        }

        CameraRecord(
            id = id,
            listed = listed,
            parentLogicalId = parentLogicalId,
            facing = c.get(CameraCharacteristics.LENS_FACING),
            focalLengths = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
                ?: floatArrayOf(),
            sensorSize = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE),
            physicalIds = c.physicalCameraIds,
            capabilities = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?: intArrayOf(),
            zoomRatioRange = if (Build.VERSION.SDK_INT >= 30) {
                c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            } else null,
            aeFpsRanges = aeRanges,
            highSpeedProfiles = hsProfiles,
            hardwareLevel = c.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL),
            activePhysicalResultKey =
                resultKeys?.contains(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID) == true
        )
    }.getOrNull()

    private fun buildDiagnostics(listedIds: Set<String>): String = buildString {
        appendLine("GT6 Optical Lens Test v2.2")
        appendLine("Android ${Build.VERSION.RELEASE} / API ${Build.VERSION.SDK_INT}")
        appendLine("Device ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("listedCameraIds=${listedIds.sorted()}")
        appendLine("mainRearId=$mainRearId")
        appendLine("logicalRearId=$logicalRearId")
        appendLine("mainPhysicalCandidateId=$mainPhysicalCandidateId")
        appendLine("teleDirectId=$teleDirectId")
        appendLine("telePhysicalCandidateId=$telePhysicalCandidateId")
        appendLine("requestedFpsRange=${requestedFpsRange ?: "AUTO"}")
        appendLine()
        records.forEach { r ->
            appendLine("cameraId=${r.id}${if (r.listed) " [PUBLIC]" else " [PHYSICAL/HIDDEN]"}")
            appendLine("  parentLogicalId=${r.parentLogicalId ?: "-"}")
            appendLine("  facing=${facingName(r.facing)}")
            appendLine("  logical=${r.isLogical}")
            appendLine("  focalLengths=${r.focalLengths.joinToString(prefix = "[", postfix = "]") { "%.2f".format(Locale.US, it) }} mm")
            appendLine("  sensorSize=${r.sensorSize?.width}x${r.sensorSize?.height} mm")
            appendLine("  eq35Horizontal≈${if (r.eq35Horizontal > 0f) "%.1f".format(Locale.US, r.eq35Horizontal) else "?"} mm")
            appendLine("  role=${cameraRole(r)}")
            appendLine("  physicalIds=${if (r.physicalIds.isEmpty()) "[]" else r.physicalIds}")
            appendLine("  AE_FPS=${fpsRangesText(r.aeFpsRanges)}")
            appendLine("  HIGH_SPEED=${if (r.highSpeedProfiles.isEmpty()) "none" else r.highSpeedProfiles.joinToString()}")
            appendLine("  activePhysicalResultKey=${r.activePhysicalResultKey}")
            appendLine("  zoomRatioRange=${r.zoomRatioRange ?: "n/a"}")
            appendLine("  HW=${hardwareLevelName(r.hardwareLevel)}")
            appendLine("  caps=${r.capabilities.joinToString()}")
        }
    }

    private fun compactSummary(): String {
        val publicRear = records.filter {
            it.listed && it.facing == CameraCharacteristics.LENS_FACING_BACK
        }
        val physical = records.filter { it.parentLogicalId != null }.distinctBy { it.id }
        val main = mainOpticalBaseline()

        return buildString {
            appendLine("PUBLIC rear: ${publicRear.size}   PHYSICAL: ${physical.size}")
            appendLine(
                "MAIN=${mainRearId ?: "-"}  LOGICAL=${logicalRearId ?: "-"}" +
                    "  MAIN_PHYS=${mainPhysicalCandidateId ?: "-"}"
            )
            appendLine(
                "TELE direct=${teleDirectId ?: "NONE"}   " +
                    "TELE physical=${telePhysicalCandidateId ?: "NONE"}"
            )
            if (main != null) {
                appendLine(
                    "BASE MAIN: f=${focalText(main)}" +
                        if (main.eq35Horizontal > 0f) {
                            " eq≈${"%.0f".format(Locale.US, main.eq35Horizontal)}mm"
                        } else ""
                )
            }

            publicRear.forEach { r ->
                append("ID ${r.id}: ${if (r.isLogical) "LOGICAL/" else ""}${cameraRole(r)}")
                append("  f=${focalText(r)}")
                if (r.eq35Horizontal > 0f) {
                    append(" eq≈${"%.0f".format(Locale.US, r.eq35Horizontal)}mm")
                }
                if (r.isLogical) append(" p=${r.physicalIds}")
                appendLine()
            }

            physical.forEach { r ->
                append("P ${r.id}: ${cameraRole(r)}  f=${focalText(r)}")
                if (r.eq35Horizontal > 0f) {
                    append(" eq≈${"%.0f".format(Locale.US, r.eq35Horizontal)}mm")
                }
                appendLine()
            }

            val fpsRec = logicalRearId?.let { recordById[it] }
                ?: mainRearId?.let { recordById[it] }
            if (fpsRec != null) {
                appendLine("AE FPS: ${fpsRangesText(fpsRec.aeFpsRanges)}")
                append("HS: ")
                append(
                    if (fpsRec.highSpeedProfiles.isEmpty()) "none"
                    else fpsRec.highSpeedProfiles.take(4).joinToString()
                )
            }
        }
    }

    private fun bindCamera(cameraId: String, initialZoom: Float, physicalId: String?) {
        val provider = provider ?: return

        if (physicalId != null) {
            val valid = recordById[cameraId]?.physicalIds ?: emptySet()
            if (physicalId !in valid) {
                toast("Physical $physicalId не принадлежит logical $cameraId")
                return
            }
        }

        runCatching {
            val selector = CameraSelector.Builder()
                .addCameraFilter { infos ->
                    infos.filter { info ->
                        runCatching { Camera2CameraInfo.from(info).cameraId == cameraId }
                            .getOrDefault(false)
                    }
                }
                .build()

            // Conservative 1080p preview improves compatibility with logical/physical camera combinations.
            val resolutionSelector = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .setResolutionStrategy(
                    ResolutionStrategy(
                        Size(1920, 1080),
                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER
                    )
                )
                .build()

            val previewBuilder = Preview.Builder().setResolutionSelector(resolutionSelector)
            Camera2Interop.Extender(previewBuilder).apply {
                setSessionCaptureCallback(captureCallback)
                requestedFpsRange?.let {
                    setCaptureRequestOption(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it)
                }
                if (physicalId != null) setPhysicalCameraId(physicalId)
            }
            val preview = previewBuilder.build().also {
                it.setSurfaceProvider(binding.preview.surfaceProvider)
            }

            // Remove observers from the previous CameraInfo before rebinding.
            camera?.cameraInfo?.zoomState?.removeObservers(this)
            provider.unbindAll()
            resetCaptureTelemetry()

            camera = provider.bindToLifecycle(this, selector, preview)
            activeCameraId = cameraId
            forcedPhysicalId = physicalId
            observeZoom(cameraId, initialZoom)
            updateLiveStatus()
        }.onFailure { e ->
            forcedPhysicalId = null
            activeCameraId = null
            camera = null
            toast("Не удалось открыть $cameraId${physicalId?.let { " / phys=$it" } ?: ""}: ${e.javaClass.simpleName}")
            binding.liveStatus.text = "OPEN ERROR: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private val captureCallback = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(
            session: CameraCaptureSession,
            request: CaptureRequest,
            result: TotalCaptureResult
        ) {
            activePhysicalIdFromResult = runCatching {
                result.get(CaptureResult.LOGICAL_MULTI_CAMERA_ACTIVE_PHYSICAL_ID)
            }.getOrNull()
            captureFocalMm = runCatching { result.get(CaptureResult.LENS_FOCAL_LENGTH) }.getOrNull()
            captureZoomRatio = if (Build.VERSION.SDK_INT >= 30) {
                runCatching { result.get(CaptureResult.CONTROL_ZOOM_RATIO) }.getOrNull()
            } else null

            val sensorTs = runCatching { result.get(CaptureResult.SENSOR_TIMESTAMP) }.getOrNull() ?: 0L
            if (sensorTs > 0L && lastSensorTimestampNs > 0L) {
                val dt = sensorTs - lastSensorTimestampNs
                if (dt in 1_000_000L..1_000_000_000L) {
                    val instant = 1_000_000_000f / dt.toFloat()
                    captureFps = if (captureFps <= 0f) instant else captureFps * 0.90f + instant * 0.10f
                }
            }
            if (sensorTs > 0L) lastSensorTimestampNs = sensorTs

            val now = System.nanoTime()
            if (now - lastHudUpdateNs >= 180_000_000L) {
                lastHudUpdateNs = now
                runOnUiThread { updateLiveStatus() }
            }
        }
    }

    private fun observeZoom(cameraId: String, initialZoom: Float) {
        val cam = camera ?: return
        cam.cameraInfo.zoomState.observe(this) { zs ->
            if (zs == null) return@observe
            val min = zs.minZoomRatio
            val max = max(min, zs.maxZoomRatio)
            val now = zs.zoomRatio
            binding.zoomLabel.text = "Zoom %.2f×  [%.1f..%.1f]".format(Locale.US, now, min, max)
            val p = if (max <= min) 0 else (((now - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
            binding.zoomSeek.progress = p
        }

        val range = recordById[cameraId]?.zoomRatioRange
        val desired = if (range != null) initialZoom.coerceIn(range.lower, range.upper) else initialZoom.coerceAtLeast(1f)
        requestZoom(desired, reportError = true)
    }

    private fun requestZoom(ratio: Float, reportError: Boolean) {
        val cam = camera ?: return
        val future = runCatching { cam.cameraControl.setZoomRatio(ratio) }.getOrElse { e ->
            if (reportError) toast("Zoom error: ${e.javaClass.simpleName}")
            return
        }
        future.addListener({
            runCatching { future.get() }.onFailure { e ->
                if (reportError) runOnUiThread {
                    toast("Zoom %.2f× rejected: %s".format(Locale.US, ratio, e.javaClass.simpleName))
                }
            }
        }, cameraExecutor)
    }

    private fun updateLiveStatus() {
        val openId = activeCameraId ?: "-"
        val openRecord = recordById[openId]
        val metadataPhysical = activePhysicalIdFromResult
        val effectiveId = when {
            metadataPhysical != null -> metadataPhysical
            forcedPhysicalId != null -> forcedPhysicalId
            openRecord?.isLogical == false -> openId
            else -> null
        }
        val effectiveText = when {
            metadataPhysical != null -> metadataPhysical
            forcedPhysicalId != null -> "${forcedPhysicalId} (requested)"
            openRecord?.isLogical == false -> openId
            else -> "UNKNOWN"
        }
        val effectiveRecord = effectiveId?.let { recordById[it] }
        val activeRole = effectiveRecord?.let { cameraRole(it) }
            ?: if (openRecord != null && !openRecord.isLogical) cameraRole(openRecord) else "UNKNOWN"

        val forceConfirm = when {
            forcedPhysicalId == null -> "n/a"
            metadataPhysical == forcedPhysicalId -> "YES"
            metadataPhysical != null -> "NO"
            else -> "?"
        }
        val keyState = when {
            openRecord == null -> "?"
            openRecord.activePhysicalResultKey -> "YES"
            else -> "NO"
        }

        binding.liveStatus.text = buildString {
            appendLine(
                "OPEN $openId${if (openRecord?.isLogical == true) " | LOGICAL" else ""}" +
                    " | ACTIVE ROLE=$activeRole"
            )
            appendLine("FORCED PHYS=${forcedPhysicalId ?: "-"}  CONFIRM=$forceConfirm")
            appendLine("ACTIVE PHYS=$effectiveText   RESULT KEY=$keyState")
            appendLine(
                "FRAME f=${captureFocalMm?.let { "%.2fmm".format(Locale.US, it) } ?: "?"}" +
                    "  zoom=${captureZoomRatio?.let { "%.2f×".format(Locale.US, it) } ?: "?"}" +
                    "  CAP=${if (captureFps > 0f) "%.1f fps".format(Locale.US, captureFps) else "?"}"
            )
            append(
                "FPS REQ=${requestedFpsRange?.let { "${it.lower}-${it.upper}" } ?: "AUTO"}" +
                    "  AE=${openRecord?.let { fpsRangesText(it.aeFpsRanges) } ?: "?"}"
            )
        }
    }

    private fun resetCaptureTelemetry() {
        activePhysicalIdFromResult = null
        captureFocalMm = null
        captureZoomRatio = null
        captureFps = 0f
        lastSensorTimestampNs = 0L
        lastHudUpdateNs = 0L
    }

    private fun fpsRangesText(ranges: List<Range<Int>>): String =
        if (ranges.isEmpty()) "none"
        else ranges.joinToString(prefix = "[", postfix = "]") { "${it.lower}-${it.upper}" }

    private fun focalText(r: CameraRecord): String =
        if (r.focalLengths.isEmpty()) "?" else r.focalLengths.joinToString("/") { "%.1fmm".format(Locale.US, it) }

    private fun copyDiagnostics() {
        val live = buildString {
            appendLine(diagnostics)
            appendLine("--- LIVE ---")
            appendLine("activeCameraId=$activeCameraId")
            appendLine("forcedPhysicalId=$forcedPhysicalId")
            appendLine("activePhysicalIdFromResult=$activePhysicalIdFromResult")
            appendLine("captureFocalMm=$captureFocalMm")
            appendLine("captureZoomRatio=$captureZoomRatio")
            appendLine("captureFps=${"%.2f".format(Locale.US, captureFps)}")
            appendLine("requestedFpsRange=${requestedFpsRange ?: "AUTO"}")
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("GT6 camera diagnostics v2.2", live))
        toast("Camera diagnostics v2.2 скопированы")
    }

    private fun facingName(v: Int?): String = when (v) {
        CameraCharacteristics.LENS_FACING_BACK -> "BACK"
        CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
        CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
        else -> "UNKNOWN"
    }

    private fun hardwareLevelName(v: Int?): String = when (v) {
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
        CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
        else -> "UNKNOWN"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        camera?.cameraInfo?.zoomState?.removeObservers(this)
        provider?.unbindAll()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
